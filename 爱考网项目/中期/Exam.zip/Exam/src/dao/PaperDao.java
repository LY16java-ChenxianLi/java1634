package dao;

import java.util.List;
import java.util.Set;

import org.hibernate.Query;
import org.hibernate.Session;

import po.Paper;
import po.Question;
import tools.HibernateSessionFactory;

public class PaperDao {
	public List<Paper> pList() {
		Session session = HibernateSessionFactory.getSession();
		session.beginTransaction();
		String hql = "select p from Paper p";
		Query query = session.createQuery(hql);
		List<Paper> papers = query.list();
		session.beginTransaction().commit();
		session.close();
		return papers;
	}
	public Set<Question> questinSet(int pid) {
		Session session = HibernateSessionFactory.getSession();
		session.beginTransaction();
		Paper pa=(Paper) session.get(Paper.class, pid);
		Set<Question> questinSet=pa.getQuestionset();
		System.out.println(questinSet);
		session.beginTransaction().commit();
		session.close();
		return questinSet;
	}
	public void stateSet(int pid,Paper paper) {
		Session session = HibernateSessionFactory.getSession();
		session.beginTransaction();
		Paper pa=(Paper) session.get(Paper.class, pid);
		pa.setState(paper.getState());
		pa.setClassName(paper.getClassName());
		pa.setTestTime(paper.getTestTime());
		session.update(pa);
		session.beginTransaction().commit();
		session.close();
		
	}
}
