package action;

import java.util.List;

import org.hibernate.Session;


import po.Student;
import tools.HibernateSessionFactory;



import com.opensymphony.xwork2.Action;

import dao.StudentDao;

public class StudentAction implements Action {
    private List<Student> studnetList;
    private int id;
	public String studnetList(){
		StudentDao stDao = new StudentDao();
		studnetList=stDao.studnetList();
		return "studnetList";
	}
	
	public String selectStudentone() {
		  Session session = HibernateSessionFactory.getSession();
		  session.beginTransaction();
		  Student student = (Student) session.get(Student.class, id); 
		  System.out.println(student);
		  session.beginTransaction().commit();
		  session.close();
		return SUCCESS;
	}
	
	public List<Student> getStudnetList() {
		return studnetList;
	}

	public void setStudnetList(List<Student> studnetList) {
		this.studnetList = studnetList;
	}
    
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	

}
