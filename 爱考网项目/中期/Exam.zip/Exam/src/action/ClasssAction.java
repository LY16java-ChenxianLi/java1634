package action;

import java.util.List;

import po.Class;



import com.opensymphony.xwork2.Action;

import dao.ClassDao;



public class ClasssAction implements Action {
    private List<Class> allClass;
	
	

	public List<Class> getAllClass() {
		return allClass;
	}

	public void setAllClass(List<Class> allClass) {
		this.allClass = allClass;
	}

	public String allClass(){
		ClassDao clDao = new ClassDao();
		allClass=clDao.AllClassList();
		return "allClass";
	}
	
	
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	

}
